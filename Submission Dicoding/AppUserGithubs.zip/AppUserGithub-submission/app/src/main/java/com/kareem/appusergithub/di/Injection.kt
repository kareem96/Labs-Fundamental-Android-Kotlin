package com.kareem.appusergithub.di

import android.content.Context
import com.kareem.appusergithub.data.local.room.UserDatabase
import com.kareem.appusergithub.data.remote.ApiConfig
import com.kareem.appusergithub.presentation.repository.Repository

object Injection {
    fun provideRepository(context: Context): Repository {
        val apiService = ApiConfig.getApiService()
        val database = UserDatabase.getInstance(context)
        val dao = database.userDao()
        return Repository.getInstance(apiService, dao)
    }
}