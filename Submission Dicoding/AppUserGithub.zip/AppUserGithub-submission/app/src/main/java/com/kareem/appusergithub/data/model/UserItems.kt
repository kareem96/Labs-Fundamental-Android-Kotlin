package com.kareem.appusergithub.data.model

data class UserItems(
    val id: Int,
    val login: String,
    val avatar_url: String,
)