package com.kareem.appusergithub.data.response

import com.kareem.appusergithub.data.model.UserItems


data class SearchResponse(
    val items: ArrayList<UserItems>
)
