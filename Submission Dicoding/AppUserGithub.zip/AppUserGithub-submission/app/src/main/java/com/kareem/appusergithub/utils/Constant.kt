package com.kareem.appusergithub.utils

object Constant {
    const val BASE_URL = "https://api.github.com/"
    const val API_KEY = "token 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"
}