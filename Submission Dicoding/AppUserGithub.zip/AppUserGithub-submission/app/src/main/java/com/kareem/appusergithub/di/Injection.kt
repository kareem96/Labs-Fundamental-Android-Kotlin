package com.kareem.appusergithub.di

object Injection {
    /*fun provideRepository(context: Context): Repository {
        val apiService = ApiConfig.getApiService()
        val database = UserDatabase.getInstance(context)
        val dao = database.userDao()
        return Repository.getInstance(apiService, dao)
    }*/
}